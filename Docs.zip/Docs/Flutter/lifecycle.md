createState
initState
didChangeDependencies
build
didUpdateWidget
setState
deactivate
dispose